﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading.Tasks;

//Stageket tárolja, amiken az alkatrész már átment
public class Steps
{
    [JsonProperty("stage_id")]
    public int StageId { get; set; }

    [JsonProperty("stage_name")]
    public string StageName { get; set; }

    [JsonProperty("done")]
    public string Done { get; set; }

    [JsonProperty("comment")]
    public string Comment { get; set; }
}

//Az alkatrészt tárolja
public class Drawing
{
    [JsonProperty("draw_number")]
    public string DrawNumber { get; set; }

    [JsonProperty("steps")]
    public List<Steps> Steps { get; set; }
}

//JSON File beolvasása
public class DrawingService
{
    public static Drawing LoadFromFile(string filePath)
    {
        if (!File.Exists(filePath))
            return null;

        try
        {
            string json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<Drawing>(json);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Hiba történt a rajz beolvasása közben: {ex.Message}");
            return null;
        }
    }

    //A rajz aktuális Stage-e alapján ellenőrzi, hogy beszerelhető-e
    public static bool IsReady(Drawing drawing)
    {
        return drawing?.Steps != null
               && drawing.Steps.Count > 0
               && drawing.Steps[0].StageId == 507
               && !string.IsNullOrEmpty(drawing.Steps[0].Done);
    }
}

//Az utolsó ellenőrzés időpontját kezeli és menti az aktuálisat
public class LastCheckStorage
{
    private readonly string _filePath;

    public LastCheckStorage(string filePath)
    {
        _filePath = filePath;
    }

    public DateTime Load()
    {
        if (File.Exists(_filePath))
        {
            string content = File.ReadAllText(_filePath);
            if (DateTime.TryParse(content, out var dt))
            {
                //UTC-ben tároljuk az időt
                return DateTime.SpecifyKind(dt, DateTimeKind.Utc);
            }
        }

        // Ha nincs mentett idő, akkor 1 nappal visszább megyünk
        return DateTime.UtcNow.AddDays(-1);
    }

    public void Save(DateTime utcTime)
    {
        // UTC-ben mentjük az időt, az "yyyy-MM-dd HH:mm:ss" formátumban
        File.WriteAllText(_filePath, utcTime.ToString("yyyy-MM-dd HH:mm:ss"));
    }
}

//Magyar időzónára vált
public static class TimeZoneHelper
{
    public static DateTime ConvertToHungarianTime(DateTime utc)
    {
        var magyarIdozona = TimeZoneInfo.FindSystemTimeZoneById("Central European Standard Time");
        return TimeZoneInfo.ConvertTimeFromUtc(utc, magyarIdozona);
    }
}

//Ellenőrzi, hogy az utolsó vizsgálat óta változott e az alkatrész állapota (igazából csak az isReady a lényeg)
public class UpdateChecker
{
    private readonly string _drawingFilePath;
    private readonly LastCheckStorage _storage;
    private bool? _isReadyPrev = null;

    public UpdateChecker(string drawingFilePath, LastCheckStorage storage)
    {
        _drawingFilePath = drawingFilePath;
        _storage = storage;
    }

    public async Task CheckForUpdatesAsync()
    {
        DateTime lastCheckUtc = _storage.Load();
        DateTime lastCheckLocal = TimeZoneHelper.ConvertToHungarianTime(lastCheckUtc);

        string readable = lastCheckLocal.ToString("yyyy. MMMM dd. HH:mm", new System.Globalization.CultureInfo("hu-HU"));

        Console.WriteLine("------------------------------------------");
        Console.WriteLine($"[INFO] Ellenőrzés indult, utolsó frissítés: {readable}");

        Drawing drawing = DrawingService.LoadFromFile(_drawingFilePath);
        bool isReady = DrawingService.IsReady(drawing);

        if (drawing != null && _isReadyPrev != isReady)
        {
            Console.WriteLine($"[INFO] {drawing.DrawNumber} módosult alkatrész találva:\n");
            Console.WriteLine($"Rajzszám: {drawing.DrawNumber}\nKészen van-e: {isReady}");
            Console.WriteLine("------------------------------------------\n");
            _isReadyPrev = isReady;
        }
        else
        {
            Console.WriteLine("[INFO] Nincs módosult alkatrész az utolsó ellenőrzés óta.");
            Console.WriteLine("------------------------------------------\n");
        }

        // Mentés UTC-ben, mert később így konvertáljuk
        Console.WriteLine(">>> Nyomj meg egy billentyűt a kilépéshez...");
        _storage.Save(DateTime.UtcNow);
    }
}

class Program
{
    private static System.Timers.Timer updateTimer;

    static async Task Main(string[] args)
    {
        Console.WriteLine(">>> Indul az alkatrész frissítési ellenőrzés...\n");

        // JSON fájl elérési útja
        string filePath = @"C:\Users\pal.patrik\Kódok,projektek\IntraProjekt\Filekezelés\Filekezeles_0729\adatok.json";

        var storage = new LastCheckStorage("last_check.txt");
        var checker = new UpdateChecker(filePath, storage);

        // Első ellenőrzés indítása azonnal
        await checker.CheckForUpdatesAsync();

        // 10 percenkénti időzítő (600000 ms) , egyenlőre 5s tesztelés miatt
        updateTimer = new System.Timers.Timer(5000);
        updateTimer.Elapsed += async (sender, e) => await checker.CheckForUpdatesAsync();
        updateTimer.AutoReset = true;
        updateTimer.Enabled = true;


        Console.ReadKey();
    }
}

//A program lefut beállított időközönként és ellenőrzi hogy volt e változás a rajz fázisában,
//ha volt egyenlőre kiírja de valójában ide madj az add-in jön. Kérdés, hogy ha ezt mindg lefuttatja
//alkatrészenként nem e lesz túlterhelve a szerver

//Amikor az előző ellenőrzést checkolja, oda el kellene tárolni azt is, hogy mi volt az előző stage -> alapból ez az eltárolás nem fog kurvasok helyet foglalni?
