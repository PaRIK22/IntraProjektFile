﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Timers;
using System.IO;

class Program
{
    //TODO: Filekezeléssel össze kell mixelni még

    // Laravel API végpont URL-je
    private static readonly string apiUrl = "/api/drawing_is_ready?draw_number=25-0441-T36554-\r\n22";

    // Fájl neve, ahová az utolsó lekérdezési időpontot mentjük
    private static readonly string lastCheckFilePath = "last_check.txt";

    // HTTP kliens példány – egy alkalmazásban lehet singleton
    private static readonly HttpClient httpClient = new HttpClient();

    // Az időzítő, ami 10 percenként lefuttatja az ellenőrzést
    private static System.Timers.Timer updateTimer;

    static async Task Main(string[] args)
    {
        Console.WriteLine(">>> Indul az alkatrész frissítési ellenőrzés...");

        // Időzítő beállítása 10 percenkénti lefutásra (600 000 ms)
        updateTimer = new System.Timers.Timer(10000);
        updateTimer.Elapsed += async (sender, e) => await CheckForUpdates(); // eseménykezelő
        updateTimer.AutoReset = true; // újrainduljon automatikusan
        updateTimer.Enabled = true;

        // Első indításkor rögtön futtassuk le egyszer az ellenőrzést
        await CheckForUpdates();

        // Futásban tartjuk a konzolalkalmazást
        Console.WriteLine(">>> Nyomj meg egy billentyűt a kilépéshez...");
        Console.ReadKey();
    }


    //Frissített alkatrészek lekérése és feldolgozása

    private static async Task CheckForUpdates()
    {
        // Betöltjük az utolsó lekérdezés időpontját a fájlból
        DateTime lastCheck = LoadLastCheckTime();

        // Done mező
        string sinceParam = Uri.EscapeDataString(lastCheck.ToString("yyyy-MM-dd HH:mm:ss")); 

        Console.WriteLine($"[INFO] Ellenőrzés indult, utolsó frissítés: {sinceParam}");

        try
        {
            // HTTP GET kérés az API végponthoz, 'since' paraméterrel
            HttpResponseMessage response = await httpClient.GetAsync($"{apiUrl}?since={sinceParam}");

            // Hibát dob, ha nem sikeres a válasz (pl. 500 vagy 404)
            response.EnsureSuccessStatusCode();

            // A válasz tartalmának (JSON) beolvasása INNENTŐL BENNEVAN A FILEKEZLÉSBEN
            string json = await response.Content.ReadAsStringAsync();

            // JSON deszerializálása C# Part objektumokká (kis-nagybetű érzékenység ki van kapcsolva)
            var parts = JsonSerializer.Deserialize<List<Part>>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });

            // Ha van frissített adat, dolgozzuk fel
            if (parts != null && parts.Count > 0)
            {
                Console.WriteLine($"[INFO] {parts.Count} módosult alkatrész találva:");
                foreach (var part in parts)
                {
                    // DEBUG Egyenlőre, utána Kirire vár
                    Console.WriteLine($" - ID: {part.Id}, Név: {part.Name}, Módosítva: {part.UpdatedAt}");
                }
            }
            else
            {
                Console.WriteLine("[INFO] Nincs módosult alkatrész az utolsó ellenőrzés óta.");
            }

            // Aktuális időpont mentése következő ellenőrzéshez
            SaveLastCheckTime(DateTime.UtcNow);
        }
        catch (Exception ex)
        {
            // Ha hiba történik, itt logoljuk ki
            Console.WriteLine($"[HIBA] Lekérdezés sikertelen: {ex.Message}");
        }
    }

    // Betölti az utolsó sikeres ellenőrzés időpontját a fájlból
    // Dátum/idő (UTC)
    private static DateTime LoadLastCheckTime()
    {
        if (File.Exists(lastCheckFilePath))
        {
            string content = File.ReadAllText(lastCheckFilePath);
            if (DateTime.TryParse(content, out var dt))
                return dt;
        }

        // Ha még nem volt ellenőrzés, nézzünk vissza 1 napot (biztonságból)
        return DateTime.UtcNow.AddDays(-1);
    }

    // Elmenti a legutóbbi sikeres ellenőrzés időpontját fájlba
    private static void SaveLastCheckTime(DateTime time)
    {
        File.WriteAllText(lastCheckFilePath, time.ToString("yyyy-MM-dd HH:mm:ss")); // Done mező
    }
}

// Alkatrészekhez tartozó C# modell osztály – JSON-ből töltődik be !!CSAK DEBUGHOZ, VAN MÁR JÓ !!
public class Part
{
    [JsonPropertyName("id")]
    public int Id { get; set; }

    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("updated_at")]
    public DateTime UpdatedAt { get; set; }
}
