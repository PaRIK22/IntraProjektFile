﻿using Newtonsoft.Json;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using System;
using System.IO;


class Program
{
    // A rajzot reprezentáló osztály
    public class Drawing
    {
        [JsonProperty("draw_number")]
        public string DrawNumber { get; set; }

        [JsonProperty("is_ready")]
        public bool IsReady { get; set; }   
    }

    //Megnyitja a metódus a JSON fájlt és visszaadja a benne lévő adatokat
    public static string JsonOpen(string filePath)
    {
        if (File.Exists(filePath))
        {
            try
            {
                string jsonContent = File.ReadAllText(filePath);
                //A JSON adat deszerializálása a Drawing osztályba
                Drawing rajz = JsonConvert.DeserializeObject<Drawing>(jsonContent);
                if (rajz.IsReady)
                    return rajz.DrawNumber;
                else
                    return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Hiba történt a fájl olvasása közben: " + ex.Message);
                return null;
            }
        }
        else
        {
            Console.WriteLine("A fájl nem található: " + filePath);
            return null;
        }
    }


    static void Main(string[] args)
    {
        List<string> readyDrawings = new List<string>();
        //Ahány rajz van annyira kell a for-t bővíteni, esetleg megoldható majd whilal ehelyett
        for (int i = 0; i < 3; i++)
        {
            // JSON fájl elérési útja
            string filePath = "C:\\Users\\pal.patrik\\Kódok,projektek\\IntraProjekt\\Filekezelés\\IsReadyHttpValaszKezelese\\adatok" + i + ".json"; //Ide jön majd a Laravel válasz, lehet célszerű erre egy külön mappa majd

            // JSON fájl megnyitása és adatainak lekérése
            string rajzszam = JsonOpen(filePath);

            if(rajzszam != null)
            {
                Console.WriteLine($"A {rajzszam} rajz beszerelesre kesz");
                readyDrawings.Add(rajzszam);
            }
                
        }

    }
}

