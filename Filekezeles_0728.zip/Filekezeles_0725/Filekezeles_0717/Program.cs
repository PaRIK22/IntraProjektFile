﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using static System.Runtime.InteropServices.JavaScript.JSType;

class Program
{
    //Az alkatrészadat változás ellenőrzéséhez szükséges
    public static bool? isReadyPrev = null;

    //Az egyes lépések adatai egy alkatrészhez
    public class Steps
    {
        [JsonProperty("stage_id")]
        public int StageId { get; set; }

        [JsonProperty("stage_name")]
        public string StageName { get; set; }

        [JsonProperty("done")]
        public string Done { get; set; }

        [JsonProperty("comment")]
        public string Comment { get; set; }
    }

    //Rajzszám, lépések listában
    public class Drawing
    {
        [JsonProperty("draw_number")]
        public string DrawNumber { get; set; }

        [JsonProperty("steps")]
        public List<Steps> Steps { get; set; }

        //Fájlkezelés
        public static Drawing JsonOpen(string filePath)
        {
            if (File.Exists(filePath))
            {
                try
                {
                    // Fájl olvasása és deszerializálása
                    string data = File.ReadAllText(filePath);
                    Drawing drawing = JsonConvert.DeserializeObject<Drawing>(data);
                    return drawing;

                }
                // Hibakezelés
                catch (Exception ex)
                {
                    Console.WriteLine("Hiba történt a fájl olvasása közben: " + ex.Message);
                    return null;
                }
            }
            else
            {
                Console.WriteLine("A fájl nem található: " + filePath);
                return null;
            }
        }

        //Ellenőrzi, hogy aZ alkatrész beszerelhető-e
        public static bool IsReady(Drawing drawing)
        {
            
            if (drawing.Steps[0].StageId == 507 && !string.IsNullOrEmpty(drawing.Steps[0].Done))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    // Fájl neve, ahová az utolsó lekérdezési időpontot mentjük
    private static readonly string lastCheckFilePath = "last_check.txt";

    // Az időzítő, ami 10 percenként lefuttatja az ellenőrzést
    private static System.Timers.Timer updateTimer;

    private static DateTime LoadLastCheckTime()
    {
        if (File.Exists(lastCheckFilePath))
        {
            string content = File.ReadAllText(lastCheckFilePath);
            if (DateTime.TryParse(content, out var dt))
                return dt;
        }

        // Ha még nem volt ellenőrzés, nézzünk vissza 1 napot (biztonságból)
        return DateTime.UtcNow.AddDays(-1);
    }

    private static void SaveLastCheckTime(DateTime time)
    {
        File.WriteAllText(lastCheckFilePath, time.ToString("yyyy-MM-dd HH:mm:ss")); // Done mező
    }

    private static async Task CheckForUpdates(string filePath)
    {
        // Betöltjük az utolsó lekérdezés időpontját a fájlból
        DateTime lastCheck = LoadLastCheckTime();

        // Done mező
        string sinceParam = Uri.EscapeDataString(lastCheck.ToString("yyyy-MM-dd HH:mm:ss"));

        Console.WriteLine("------------------------------------------");
        Console.WriteLine($"[INFO] Ellenőrzés indult, utolsó frissítés: {sinceParam}");

        Drawing drawing = Drawing.JsonOpen(filePath);
        bool isReady = Drawing.IsReady(drawing);


        try
        {
            // Ha van frissített adat, dolgozzuk fel
            if (drawing != null && Program.isReadyPrev != isReady) //&& drawing.Count > 0
            {
                Console.WriteLine($"[INFO] {drawing.DrawNumber} módosult alkatrész találva:");
                Console.WriteLine("------------------------------------------");
                // DEBUG Egyenlőre, utána Kirire vár
                Console.WriteLine($" Rajzszám: {drawing.DrawNumber}\n Készen van e: {isReady}");
                Console.WriteLine("------------------------------------------\n");
                isReadyPrev = isReady;

            }
            else
            {
                Console.WriteLine("[INFO] Nincs módosult alkatrész az utolsó ellenőrzés óta.");
                Console.WriteLine("------------------------------------------\n");
            }

            // Aktuális időpont mentése következő ellenőrzéshez
            SaveLastCheckTime(DateTime.UtcNow);
        }
        catch (Exception ex)
        {
            // Ha hiba történik, itt logoljuk ki
            Console.WriteLine($"[HIBA] Lekérdezés sikertelen: {ex.Message}");
        }

        Console.WriteLine(">>> Nyomj meg egy billentyűt a kilépéshez...\n");
    }

    static void Main(string[] args)
    {
        //Ide jön majd a JSON a Laravelből, egyenlőre csak példa,ide kell menteni a laraveles json filet
        string filePath = "C:\\Users\\pal.patrik\\Kódok,projektek\\IntraProjekt\\Filekezelés\\Filekezeles_0725\\adatok.json";
        //Függvény hívása


        Console.WriteLine(">>> Indul az alkatrész frissítési ellenőrzés...\n");

        // Időzítő beállítása 10 percenkénti lefutásra (600 000 ms)
        updateTimer = new System.Timers.Timer(5000);
        updateTimer.Elapsed += async (sender, e) => await CheckForUpdates(filePath); // eseménykezelő
        updateTimer.AutoReset = true; // újrainduljon automatikusan
        updateTimer.Enabled = true;

        // Első indításkor rögtön futtassuk le egyszer az ellenőrzést
        CheckForUpdates(filePath);

        // Futásban tartjuk a konzolalkalmazást
        Console.ReadKey();
    }
}
